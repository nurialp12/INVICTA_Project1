# Repeaters Studio

Repository dedicated to the project releases from the Project 1 subject from GDDV (CITM, UPC).



## Team Members

* Pol Gannau
> https://github.com/PolGannau

* Marc Rosell
>https://github.com/MarcRosellH

* Oscar Reguera
>https://github.com/oscarrep

* Jan Adell
>https://github.com/JanAdell

### Project Website

[Repeaters Studio's Website](https://polgannau.github.io/RepeatersStudio/)

### Project Wiki

[Repeaters Studio's Wiki](https://github.com/PolGannau/RepeatersStudio/wiki)

### Github link

[Repeaters Studio's Github](https://github.com/PolGannau/RepeatersStudio/)


